// Utility functions for business days calculation

export const isBusinessDay = (date: Date): boolean => {
  const day = date.getDay();
  return day !== 0 && day !== 6; // 0 = Sunday, 6 = Saturday
};

export const addBusinessDays = (date: Date, days: number): Date => {
  let newDate = new Date(date.getTime());
  let count = 0;
  while (count < days) {
    newDate.setDate(newDate.getDate() + 1);
    if (isBusinessDay(newDate)) {
      count++;
    }
  }
  return newDate;
};

export const formatDateToBR = (date: Date): string => {
  return date.toLocaleDateString('pt-BR');
};

export const calculateDeadlineStatus = (notificationDate: string): { prazoStatus: 'Em prazo' | 'Fora do prazo'; prazoFinal: string } => {
  const notifDate = new Date(notificationDate + 'T00:00:00');
  const deadline = addBusinessDays(notifDate, 10);
  const now = new Date();
  const isWithinDeadline = now <= deadline;
  
  return {
    prazoStatus: isWithinDeadline ? 'Em prazo' : 'Fora do prazo',
    prazoFinal: formatDateToBR(deadline)
  };
};
