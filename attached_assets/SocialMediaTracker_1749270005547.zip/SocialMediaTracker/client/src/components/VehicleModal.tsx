import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import type { Vehicle, InsertVehicle } from '@shared/schema';

interface VehicleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (vehicleData: InsertVehicle) => Promise<void>;
  editingVehicle: Vehicle | null;
  userMatricula: string;
}

const VehicleModal: React.FC<VehicleModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  editingVehicle,
  userMatricula
}) => {
  const [formData, setFormData] = useState<InsertVehicle>({
    placa: '',
    endereco: '',
    dataNotificacao: '',
    matriculaAgente: userMatricula,
    status: 'aguardando remoção'
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (editingVehicle) {
      setFormData({
        placa: editingVehicle.placa,
        endereco: editingVehicle.endereco,
        dataNotificacao: editingVehicle.dataNotificacao,
        matriculaAgente: editingVehicle.matriculaAgente,
        status: editingVehicle.status
      });
    } else {
      setFormData({
        placa: '',
        endereco: '',
        dataNotificacao: '',
        matriculaAgente: userMatricula,
        status: 'aguardando remoção'
      });
    }
    setError('');
  }, [editingVehicle, userMatricula, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validation
    if (!/^\d{5}$/.test(formData.matriculaAgente)) {
      setError('A matrícula do agente deve conter 5 dígitos numéricos.');
      setLoading(false);
      return;
    }

    if (isNaN(new Date(formData.dataNotificacao).getTime())) {
      setError('Data de Notificação inválida.');
      setLoading(false);
      return;
    }

    try {
      await onSubmit({
        ...formData,
        placa: formData.placa.toUpperCase()
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Erro ao salvar veículo');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: keyof InsertVehicle, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {editingVehicle ? 'Editar Veículo' : 'Adicionar Novo Veículo'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="vehiclePlate">Placa do Veículo *</Label>
              <Input
                id="vehiclePlate"
                type="text"
                required
                value={formData.placa}
                onChange={(e) => handleInputChange('placa', e.target.value)}
                placeholder="Ex: ABC-1234"
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="agentMatricula">Matrícula do Agente *</Label>
              <Input
                id="agentMatricula"
                type="text"
                required
                maxLength={5}
                value={formData.matriculaAgente}
                onChange={(e) => handleInputChange('matriculaAgente', e.target.value)}
                placeholder="5 dígitos"
                className="mt-1"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="vehicleAddress">Endereço Completo *</Label>
            <Textarea
              id="vehicleAddress"
              rows={3}
              required
              value={formData.endereco}
              onChange={(e) => handleInputChange('endereco', e.target.value)}
              placeholder="Digite o endereço completo onde o veículo foi encontrado"
              className="mt-1"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="notificationDate">Data da Notificação *</Label>
              <Input
                id="notificationDate"
                type="date"
                required
                value={formData.dataNotificacao}
                onChange={(e) => handleInputChange('dataNotificacao', e.target.value)}
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="vehicleStatus">Status *</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => handleInputChange('status', value)}
                required
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aguardando remoção">Aguardando Remoção</SelectItem>
                  <SelectItem value="removido ao pátio">Removido ao Pátio</SelectItem>
                  <SelectItem value="removido pelo proprietário">Removido pelo Proprietário</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {error && (
            <div className="text-red-600 text-sm">
              {error}
            </div>
          )}
          
          <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-primary hover:bg-primary/90"
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3-3m0 0l-3 3m3-3v12" />
              </svg>
              {loading ? 'Salvando...' : 'Salvar Veículo'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default VehicleModal;
