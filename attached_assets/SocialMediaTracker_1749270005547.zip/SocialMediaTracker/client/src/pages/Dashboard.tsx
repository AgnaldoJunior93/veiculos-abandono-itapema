import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import StatsCards from '@/components/StatsCards';
import VehicleTable from '@/components/VehicleTable';
import VehicleModal from '@/components/VehicleModal';
import type { Vehicle, InsertVehicle, Stats } from '@shared/schema';

const Dashboard: React.FC = () => {
  const { user, logoutUser } = useAuth();
  const [filteredVehicles, setFilteredVehicles] = useState<Vehicle[]>([]);
  const [currentFilter, setCurrentFilter] = useState('Todos');
  const [showModal, setShowModal] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [stats, setStats] = useState<Stats>({ total: 0, pending: 0, removed: 0, overdue: 0 });

  const queryClient = useQueryClient();

  // Load vehicles from API
  const { data: vehicles = [], isLoading, error } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
    queryFn: async () => {
      const response = await fetch('/api/vehicles');
      if (!response.ok) throw new Error('Erro ao carregar veículos');
      return response.json();
    },
    enabled: !!user,
    refetchInterval: 30000, // Refetch every 30 seconds for real-time updates
  });

  // Calculate stats
  useEffect(() => {
    const total = vehicles.length;
    const pending = vehicles.filter(v => v.status === 'aguardando remoção').length;
    const removed = vehicles.filter(v => v.status === 'removido ao pátio' || v.status === 'removido pelo proprietário').length;
    const overdue = vehicles.filter(v => v.prazoStatus === 'Fora do prazo').length;

    setStats({ total, pending, removed, overdue });
  }, [vehicles]);

  // Apply filter
  useEffect(() => {
    if (currentFilter === 'Todos') {
      setFilteredVehicles(vehicles);
    } else {
      setFilteredVehicles(vehicles.filter(v => v.status === currentFilter));
    }
  }, [vehicles, currentFilter]);

  const handleAddVehicle = () => {
    setEditingVehicle(null);
    setShowModal(true);
  };

  const handleEditVehicle = (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setShowModal(true);
  };

  // Mutations for vehicle operations
  const createVehicleMutation = useMutation({
    mutationFn: async (vehicleData: InsertVehicle) => {
      const response = await fetch('/api/vehicles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(vehicleData),
      });
      if (!response.ok) throw new Error('Erro ao criar veículo');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      setShowModal(false);
    },
  });

  const updateVehicleMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertVehicle> }) => {
      const response = await fetch(`/api/vehicles/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Erro ao atualizar veículo');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      setShowModal(false);
    },
  });

  const deleteVehicleMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/vehicles/${id}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Erro ao excluir veículo');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
    },
  });

  const handleSubmitVehicle = async (vehicleData: InsertVehicle): Promise<void> => {
    if (!user) throw new Error('Usuário não autenticado');

    try {
      if (editingVehicle) {
        // Permission check for editing
        if (user.type === 'Administrador' || (user.type === 'Padrão' && user.matricula === editingVehicle.matriculaAgente)) {
          await updateVehicleMutation.mutateAsync({
            id: editingVehicle.id,
            data: vehicleData
          });
        } else {
          throw new Error('Você não tem permissão para alterar este veículo.');
        }
      } else {
        await createVehicleMutation.mutateAsync(vehicleData);
      }
    } catch (error: any) {
      throw new Error(error.message || 'Erro ao salvar veículo.');
    }
  };

  const handleDeleteVehicle = async (id: string) => {
    if (!user) return;

    if (user.type !== 'Administrador') {
      alert('Você não tem permissão para excluir veículos.');
      return;
    }

    if (window.confirm('Tem certeza que deseja excluir este veículo?')) {
      try {
        await deleteVehicleMutation.mutateAsync(id);
      } catch (error) {
        console.error("Erro ao excluir veículo:", error);
        alert('Erro ao excluir veículo. Verifique as permissões.');
      }
    }
  };

  const filters = ['Todos', 'aguardando remoção', 'removido ao pátio', 'removido pelo proprietário'];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <svg className="w-4 h-4 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2v0M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" />
                  </svg>
                </div>
                <h1 className="ml-3 text-xl font-semibold text-gray-900">
                  Veículos Abandono Itapema
                </h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-sm text-gray-700">
                <svg className="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                <span>{user.name}</span>
                <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                  {user.type}
                </span>
              </div>
              <button onClick={logoutUser} className="text-gray-500 hover:text-gray-700 transition-colors">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Gestão de Veículos Abandonados</h2>
          <p className="text-gray-600">Acompanhe e gerencie os veículos notificados no município</p>
        </div>

        {/* Stats Cards */}
        <StatsCards stats={stats} />

        {/* Filters and Actions */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6 border border-gray-200">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex flex-wrap gap-2">
              {filters.map(filter => (
                <button
                  key={filter}
                  onClick={() => setCurrentFilter(filter)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    currentFilter === filter 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {filter.charAt(0).toUpperCase() + filter.slice(1)}
                </button>
              ))}
            </div>
            
            {(user.type === 'Administrador' || user.type === 'Padrão') && (
              <button
                onClick={handleAddVehicle}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg shadow-sm hover:bg-green-700 transition-colors text-sm font-medium"
              >
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
                Adicionar Veículo
              </button>
            )}
          </div>
        </div>

        {/* Vehicles Table */}
        {isLoading ? (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-gray-600">Carregando veículos...</p>
          </div>
        ) : (
          <VehicleTable
            vehicles={filteredVehicles}
            user={user}
            onEdit={handleEditVehicle}
            onDelete={handleDeleteVehicle}
          />
        )}
      </main>

      {/* Vehicle Modal */}
      <VehicleModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onSubmit={handleSubmitVehicle}
        editingVehicle={editingVehicle}
        userMatricula={user.matricula}
      />
    </div>
  );
};

export default Dashboard;
