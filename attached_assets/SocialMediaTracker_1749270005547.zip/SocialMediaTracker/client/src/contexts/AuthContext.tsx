import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth, db, app } from '@/lib/firebase';
import { signInAnonymously, onAuthStateChanged, signInWithCustomToken, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import type { User } from '@shared/schema';

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  db: typeof db;
  appId: string;
  loginUser: (matricula: string, password: string) => Promise<void>;
  logoutUser: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  
  const appId = app.options.appId || 'default-app-id';

  useEffect(() => {
    // Check for saved user data on app load
    const savedUser = localStorage.getItem('vehicleApp_user');
    const savedFirebaseUser = localStorage.getItem('vehicleApp_firebaseUser');
    
    if (savedUser && savedFirebaseUser) {
      setUser(JSON.parse(savedUser));
      setFirebaseUser(JSON.parse(savedFirebaseUser));
    }
    
    setLoading(false);
  }, []);

  const loginUser = async (matricula: string, password: string): Promise<void> => {
    try {
      // Validate matricula format
      if (!/^\d{5}$/.test(matricula)) {
        throw new Error('Matrícula deve conter 5 dígitos numéricos.');
      }

      // Call backend API for authentication
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ matricula, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erro na autenticação');
      }

      const { user: userData } = await response.json();

      // Create a mock Firebase user object for compatibility
      const mockFirebaseUser = {
        uid: `mock-${matricula}`,
        email: null,
        displayName: userData.name
      };

      setFirebaseUser(mockFirebaseUser as any);
      setUser(userData);
      localStorage.setItem('vehicleApp_user', JSON.stringify(userData));
      localStorage.setItem('vehicleApp_firebaseUser', JSON.stringify(mockFirebaseUser));
    } catch (error: any) {
      throw new Error(error.message || 'Erro na autenticação');
    }
  };

  const logoutUser = () => {
    setUser(null);
    setFirebaseUser(null);
    localStorage.removeItem('vehicleApp_user');
    localStorage.removeItem('vehicleApp_firebaseUser');
  };

  const value: AuthContextType = {
    user,
    firebaseUser,
    db,
    appId,
    loginUser,
    logoutUser,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
