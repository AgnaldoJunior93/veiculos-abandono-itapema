import { z } from "zod";
import { pgTable, serial, varchar, text } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";

// Database Tables
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  matricula: varchar("matricula", { length: 5 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 20 }).notNull()
});

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  placa: varchar("placa", { length: 20 }).notNull().unique(),
  endereco: text("endereco").notNull(),
  dataNotificacao: varchar("data_notificacao", { length: 10 }).notNull(),
  matriculaAgente: varchar("matricula_agente", { length: 5 }).notNull(),
  status: varchar("status", { length: 50 }).notNull()
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  vehicles: many(vehicles)
}));

export const vehiclesRelations = relations(vehicles, ({ one }) => ({
  agent: one(users, {
    fields: [vehicles.matriculaAgente],
    references: [users.matricula]
  })
}));

// Zod Schemas
export const userSchema = z.object({
  id: z.number(),
  matricula: z.string().length(5, "Matrícula deve ter 5 dígitos"),
  password: z.string().min(1, "Senha é obrigatória"),
  name: z.string(),
  type: z.enum(["Administrador", "Padrão"]),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const vehicleSchema = z.object({
  id: z.string(),
  placa: z.string().min(1, "Placa é obrigatória"),
  endereco: z.string().min(1, "Endereço é obrigatório"),
  dataNotificacao: z.string().min(1, "Data de notificação é obrigatória"),
  matriculaAgente: z.string().length(5, "Matrícula do agente deve ter 5 dígitos"),
  status: z.enum(["aguardando remoção", "removido ao pátio", "removido pelo proprietário"]),
  prazoStatus: z.enum(["Em prazo", "Fora do prazo"]).optional(),
  prazoFinal: z.string().optional(),
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Vehicle = z.infer<typeof vehicleSchema>;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;

// Stats schema
export const statsSchema = z.object({
  total: z.number(),
  pending: z.number(),
  removed: z.number(),
  overdue: z.number(),
});

export type Stats = z.infer<typeof statsSchema>;
