import { users, vehicles, type User, type InsertUser, type Vehicle, type InsertVehicle } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByMatricula(matricula: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllVehicles(): Promise<Vehicle[]>;
  getVehicleById(id: number): Promise<Vehicle | undefined>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: number, vehicle: Partial<InsertVehicle>): Promise<Vehicle>;
  deleteVehicle(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByMatricula(matricula: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.matricula, matricula));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllVehicles(): Promise<Vehicle[]> {
    const result = await db.select().from(vehicles);
    return result.map(v => ({
      ...v,
      id: v.id.toString(),
      status: v.status as Vehicle['status']
    }));
  }

  async getVehicleById(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    if (!vehicle) return undefined;
    return {
      ...vehicle,
      id: vehicle.id.toString(),
      status: vehicle.status as Vehicle['status']
    };
  }

  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const [vehicle] = await db
      .insert(vehicles)
      .values(insertVehicle)
      .returning();
    return {
      ...vehicle,
      id: vehicle.id.toString(),
      status: vehicle.status as Vehicle['status']
    };
  }

  async updateVehicle(id: number, updateData: Partial<InsertVehicle>): Promise<Vehicle> {
    const [vehicle] = await db
      .update(vehicles)
      .set(updateData)
      .where(eq(vehicles.id, id))
      .returning();
    return {
      ...vehicle,
      id: vehicle.id.toString(),
      status: vehicle.status as Vehicle['status']
    };
  }

  async deleteVehicle(id: number): Promise<void> {
    await db.delete(vehicles).where(eq(vehicles.id, id));
  }
}

export const storage = new DatabaseStorage();
