import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertVehicleSchema } from "@shared/schema";
// Move business days calculation to server
const isBusinessDay = (date: Date): boolean => {
  const day = date.getDay();
  return day !== 0 && day !== 6; // 0 = Sunday, 6 = Saturday
};

const addBusinessDays = (date: Date, days: number): Date => {
  let newDate = new Date(date.getTime());
  let count = 0;
  while (count < days) {
    newDate.setDate(newDate.getDate() + 1);
    if (isBusinessDay(newDate)) {
      count++;
    }
  }
  return newDate;
};

const formatDateToBR = (date: Date): string => {
  return date.toLocaleDateString('pt-BR');
};

const calculateDeadlineStatus = (notificationDate: string): { prazoStatus: 'Em prazo' | 'Fora do prazo'; prazoFinal: string } => {
  const notifDate = new Date(notificationDate + 'T00:00:00');
  const deadline = addBusinessDays(notifDate, 10);
  const now = new Date();
  const isWithinDeadline = now <= deadline;
  
  return {
    prazoStatus: isWithinDeadline ? 'Em prazo' : 'Fora do prazo',
    prazoFinal: formatDateToBR(deadline)
  };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { matricula, password } = req.body;
      console.log('Login attempt:', { matricula, password });
      
      if (!matricula || !password) {
        return res.status(400).json({ error: 'Matrícula e senha são obrigatórios' });
      }

      const user = await storage.getUserByMatricula(matricula);
      console.log('Found user:', user);
      
      if (!user || user.password !== password) {
        console.log('Password comparison:', { userPassword: user?.password, providedPassword: password });
        return res.status(401).json({ error: 'Credenciais inválidas' });
      }

      res.json({ user: { ...user, password: undefined } });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  });

  app.post('/api/users', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json({ ...user, password: undefined });
    } catch (error) {
      console.error('Create user error:', error);
      res.status(400).json({ error: 'Dados de usuário inválidos' });
    }
  });

  // Vehicle routes
  app.get('/api/vehicles', async (req, res) => {
    try {
      const vehicles = await storage.getAllVehicles();
      
      // Calculate deadline status for each vehicle
      const vehiclesWithStatus = vehicles.map(vehicle => {
        const deadlineInfo = calculateDeadlineStatus(vehicle.dataNotificacao);
        return {
          ...vehicle,
          prazoStatus: deadlineInfo.prazoStatus,
          prazoFinal: deadlineInfo.prazoFinal
        };
      });

      res.json(vehiclesWithStatus);
    } catch (error) {
      console.error('Get vehicles error:', error);
      res.status(500).json({ error: 'Erro ao carregar veículos' });
    }
  });

  app.post('/api/vehicles', async (req, res) => {
    try {
      const vehicleData = insertVehicleSchema.parse(req.body);
      const vehicle = await storage.createVehicle(vehicleData);
      res.json(vehicle);
    } catch (error) {
      console.error('Create vehicle error:', error);
      res.status(400).json({ error: 'Dados de veículo inválidos' });
    }
  });

  app.put('/api/vehicles/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const vehicleData = insertVehicleSchema.partial().parse(req.body);
      const vehicle = await storage.updateVehicle(id, vehicleData);
      res.json(vehicle);
    } catch (error) {
      console.error('Update vehicle error:', error);
      res.status(400).json({ error: 'Erro ao atualizar veículo' });
    }
  });

  app.delete('/api/vehicles/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteVehicle(id);
      res.json({ success: true });
    } catch (error) {
      console.error('Delete vehicle error:', error);
      res.status(500).json({ error: 'Erro ao excluir veículo' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
